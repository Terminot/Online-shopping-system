<?php
if('submit'){
    $name = ['name'];
    $password = ['password'];
    

    $conn = mysqli_connect('localhost','root',"",'lgft');

    $insert = 'INSERT INTO `lg`(`name`,`password`) VALUES("$name","$password")';

    $fin = mysqli_query($conn,$insert);

    if($fin){
        echo "COPYRIGHT 2024";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="Newfolder/BigT letter.png" rel="icon">
    <link href="Style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<nav>
    <h1 class="logo">Tet shopping</h1>
    <ul>
        <li><a href="Home.php">Home</a></li>
        <li><a href="About.php">About</a></li>
        <li><a href="Shop.php">Shop</a></li>
        <li><a href="Contact.php">Contact</a></li>
    </ul>
</nav>
<br><br><br><br>
<div class="d1">
<h1>About us</h1>
</div>
<h2>Our schedule</h2>

</div>
Monday:2:30-5:34AM<hr>
Tuesday:2:30-5:34AM<hr>
Wednesday:2:30-5:34AM<hr>
Thursday:2:30-5:34AM<hr>
Friday:2:30-5:34AM<hr>
Saturday:2:30-5:34AM<hr>
Sunday:2:30-5:34AM<hr>


</body>
</html>
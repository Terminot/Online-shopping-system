<?php
@include ("config.php");

if($_POST){
$fn= $_POST['fn'];
$ln= $_POST['ln'];
$un= $_POST['un'];
$ps= $_POST['ps'];
$cp= $_POST['cp'];

$insert = "INSERT INTO `tsn`(`fn`, `ln`, `un`, `ps`, `cp`) VALUES('$fn', '$ln', '$un', '$ps', '$cp')";

$check = mysqli_query($conn, $insert);

if($ps != $cp){
    echo "PASSWORDS DO NOT MATCH";
    die();
}
if($check){
    header('location:intro.php');
}
else{
    echo "ERROR SIGNING UP";
}

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="jbl.png" rel="icon">
    <link href="Style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<nav>
    <h1 class="logo">Tet shopping</h1>
    <ul>
        <li><a href="Home.php">Home</a></li>
        <li><a href="About.php">About</a></li>
        <li><a href="Shop.php">Shop</a></li>
        <li><a href="Contact.php">Contact</a></li>
    </ul>
</nav>
<br><br><br><br>
<form class="form" method="post">
    <h1>Sign-in</h1>
        <input type="text" width="20px" name="fn" placeholder="First name" require><br><br>
        <input type="text" width="20px" name="ln" placeholder="Lastname" require><br><br>
        <input type="text" width="20px" name="un" placeholder="Username" require><br><br>
        <input type="password" name="ps" placeholder="Password" require><br><br>
        <input type="password" name="cp" placeholder="Confirm password" require><br><br>
        <button class="submit">Sign-in</button><br>
            Already have an account?<a href="Intro.php">Log-in</a>
    </form> 
</body>
</html>
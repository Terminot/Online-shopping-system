<!DOCTYPE html>
<html lang="en">
<head>
    <link href="jbl.png" rel="icon">
    <link href="Style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<nav>
    <h1 class="logo">Tet shopping</h1>
    <ul>
    <li><a href="Home.php">Home</a></li>
        <li><a href="About.php">About</a></li>
        <li><a href="Shop.php">Shop</a></li>
        <li><a href="Contact.php">Contact</a></li>

    </ul>
</nav>
<br><br><br><br>
    <form method="post" action="Redirect.php">
        <input type="text" name="username" placeholder="Username"></input>
        <select name="devsel" class="devsel" width="60%">
            <option name="">...</option>
            <option name="Silcer iMAc">Silver iMAc</option>
            <option name="Oneplus neckband">Oneplus neckband</option>
            <option name="jbl Headphhones">jbl Headphhones</option>
            <option name="Samsung Galaxy S9">Samsung Galaxy S9</option>
            <option name="Tecno spark10">Tecno spark10</option>
            <option name="Samsung galaxyS22.png">Samsung galaxy SS2</option>\
            <option name="Nokia.jpg">Nokia</option>
        </select><Br>
        <button class="submit">Buy</button>
    </form>

</body>
</html>
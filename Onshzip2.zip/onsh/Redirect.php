<?php
if($_POST){
    $n= $_POST['username'];
    $dv= $_POST['devsel'];

    $conn = mysqli_connect('localhost','root','',"onsh"); 

    $insert = "INSERT INTO `tetshop`(`username`,`devsel`) VALUES('$n', '$dv')";

    $check = mysqli_query($conn, $insert);

    if($check){
        echo "SUCCESSFULLY BOUHGHT";
    }

}    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="Newfolder/BigT letter.png" rel="icon">
    <link href="Style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<nav>
    <h1 class="logo">Tet shopping</h1>
</nav>
<br><br><br><br>
<div class="d1">
<h1>Redirect to <a href="Home.php">Home</a></h1>

</div>

</body>
</html>
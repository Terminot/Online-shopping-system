*THIS IS A ONLINE SHOPPING SYSTEM*

// You should know how to code *HTML* *CSS* *PHP* before using this code  to learn 
or change anything//


<?php
if('submit'){
    $name = ['name'];
    $password = ['password'];
    

    $conn = mysqli_connect('localhost','root',"",'lgft');

    $insert = 'INSERT INTO `lg`(`name`,`password`) VALUES("$name","$password")';

    $fin = mysqli_query($conn,$insert);

    if($fin){
        echo "COPYRIGHT 2024";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="Nokia.jpg" rel="icon">
    <link href="Style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<nav>
    <h1 class="logo">Tet shopping</h1>
    <ul>
        <li><a href="Home.php">Home</a></li>
        <li><a href="About.php">About</a></li>
        <li><a href="Shop.php">Shop</a></li>
        <li><a href="Contact.php">Contact</a></li>
    </ul>
</nav>
<center><input type="search" class="search" placeholder="Search"><center>
<br><br><br><br>

<a href="Shop-sign.php">
    <img src="img/Samsung galaxy S9.png">
    <h1>Samsung Galaxy S9</h1>
</a>
<a href="Shop-sign.php">
    <img src="img/jbl.png"><h1>jbl Headphhones</h1>
</a>
<a href="Shop-sign.php">
    <img src="img/silver iMAc .png"><h1>Silver iMAc</h1>
</a>
<a href="Shop-sign.php">
    <img src="img/Oneplus neckband.png"><h1>Oneplus neckband</h1>
</a>
<a href="Shop-sign.php">
    <img src="img/Tecno spark10.jpg"><h1>Tecno spark10</h1>
</a>
<a href="Shop-sign.php">
    <img src="img/Samsung galaxy S22.png"><h1>Samsung galaxy S22</h1>
</a>
<a href="Shop-sign.php">
    <img src="img/Nokia.jpg"><h1>Nokia</h1>
</a>
</body>
</html>
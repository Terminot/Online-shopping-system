<?php 
@include ("config.php");

if($_POST){
$un= $_POST['un'];
$ps= $_POST['ps'];


$COLLECT = "SELECT * FROM `tsn` WHERE un='$un' && ps='$ps'";

$examp = mysqli_query($conn, $COLLECT);
if(mysqli_num_rows($result) > 0){

    $row = mysqli_fetch_array($examp);

    header('location:Home.php');
}
else{
    echo "ERROR LOGGING IN";
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="jbl.png" rel="icon">
    <link href="Style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<nav>
    <h1 class="logo">Tet shopping</h1>
    <ul>
        <li><a href="">Home</a></li>
        <li><a href="">About</a></li>
        <li><a href="">Shop</a></li>
        <li><a href="">Contact</a></li>
    </ul>
</nav>
<br><br><br><br>
<form action="Home.php" method="post">
    <h1>Login</h1>
        <input type="text" width="20px" name="un" placeholder="Username" require><br><br>
        <input type="password" name="ps" placeholder="Password" require><br><br>
        <button class="submit">Sign-in</button><br>
            Dont have an account?<a href="Sign.php">Sign up</a>
    </form> 
</body>
</html>